from setuptools import setup

setup(name='colormap_dev',
      version='0.0',
      description='User defined colormaps in colormaps.dev',
      packages=['colormap_dev'],
      author_email='kwang66@illinos.edu',
      zip_safe=False)
